package com.example.submissionpemula;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Detail extends AppCompatActivity {

    public static final String EXTRA_NAME = "";
    public static final String EXTRA_DETAIL = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
    }
}
